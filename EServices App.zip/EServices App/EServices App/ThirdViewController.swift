//
//  ThirdViewController.swift
//  EServices App
//
//  Created by Admin on 16/05/1442 AH.
//  Copyright © 1442 Admin. All rights reserved.
//

import Foundation
import UIKit

class ThirdViewController: UIViewController,UITextViewDelegate, UIPickerViewDelegate {
    let SegueBooksViewController = "askvisit"
    @IBOutlet weak var ScrollView: UIScrollView!
    @IBOutlet weak var ContentView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ScrollView.delegate = self
        ScrollView.contentSize = ContentView.frame.size

    }
    
    override func didReceiveMemoryWarning() {

        super.didReceiveMemoryWarning()

        // Dispose of any resources that can be recreated.

    }

    private func scrollViewDidScroll(scrollView: UIScrollView) {

        ScrollView.contentSize = ContentView.frame.size

    }

    override func viewDidLayoutSubviews()
    {
        super.viewDidLayoutSubviews()
        print("viewDidLayoutSubviews")

        ScrollView.contentSize = ContentView.frame.size
    }
}

extension ThirdViewController: UIScrollViewDelegate
{
    func scrollViewDidScroll(_ scrollView: UIScrollView)
    {
        print("scrolling is occurring.  You can see the ScrollView scrollbars moving as well")
    }
}
