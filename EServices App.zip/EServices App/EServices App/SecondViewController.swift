//
//  SecondViewController.swift
//  IOS12TabBarControllerTutorial
//
//  Created by Arthur Knopper on 27/09/2018.
//  Copyright © 2018 Arthur Knopper. All rights reserved.
//

import UIKit
import Alamofire

class SecondViewController: UIViewController {
    let SegueBooksViewController = "Allservices"

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
       /* showInputDialog(title: "Add number",
                        subtitle: "Please enter the new number below.",
                        actionTitle: "Add",
                        cancelTitle: "Cancel",
                        inputPlaceholder: "New number",
                        inputKeyboardType: .numberPad)
        { (input:String?) in
            print("The new number is \(input ?? "")")
        }*/

    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        /*showInputDialog(title: "Add number",
                        subtitle: "Please enter the new number below.",
                        actionTitle: "Add",
                        cancelTitle: "Cancel",
                        inputPlaceholder: "New number",
                        inputKeyboardType: .numberPad)
        { (input:String?) in
            print("The new number is \(input ?? "")")
        }*/

    }
}

extension UIViewController {
    func showInputDialog(title:String? = nil,
                         subtitle:String? = nil,
                         actionTitle:String? = "Add",
                         cancelTitle:String? = "Cancel",
                         inputPlaceholder:String? = nil,
                         inputKeyboardType:UIKeyboardType = UIKeyboardType.default,
                         cancelHandler: ((UIAlertAction) -> Swift.Void)? = nil,
                         actionHandler: ((_ text: String?) -> Void)? = nil) {

        let alert = UIAlertController(title: title, message: subtitle, preferredStyle: .alert)
        alert.addTextField { (textField:UITextField) in
            textField.placeholder = inputPlaceholder
            textField.keyboardType = inputKeyboardType
        }
        alert.addAction(UIAlertAction(title: actionTitle, style: .default, handler: { (action:UIAlertAction) in
            guard let textField =  alert.textFields?.first else {
                actionHandler?(nil)
                return
            }
            actionHandler?(textField.text)
        }))
        alert.addAction(UIAlertAction(title: cancelTitle, style: .cancel, handler: cancelHandler))

        self.present(alert, animated: true, completion: nil)
    }
    func showInputDialog2(title:String? = "Faild",
                         subtitle:String? = "NO network connection",
                         //actionTitle:String? = "Done",
                         cancelTitle:String? = "Cancel",
                        // inputPlaceholder:String? = nil,
                         //inputKeyboardType:UIKeyboardType = UIKeyboardType.default,
                         cancelHandler: ((UIAlertAction) -> Swift.Void)? = nil) {

        let alert = UIAlertController(title: title, message: subtitle, preferredStyle: .alert)

        alert.addAction(UIAlertAction(title: cancelTitle, style: .cancel, handler: cancelHandler))

        self.present(alert, animated: true, completion: nil)
    }
}

