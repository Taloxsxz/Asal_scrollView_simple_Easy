//
//  FirstViewController.swift
//  IOS12TabBarControllerTutorial
//
//  Created by Arthur Knopper on 27/09/2018.
//  Copyright © 2018 Arthur Knopper. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
//import ReCaptcha

public var ItisRobort: String = "YES"

class FirstViewController: UIViewController, UITextFieldDelegate {
    
    var serviceName: Int!
    var alert = SweetAlert()
    let Segueserv1ViewController = "askvisit11"
    let Segueserv2ViewController = "sendquiry"
    let Segueserv3ViewController = "sendcomplain"
    let SegueBooksViewController = "askvisit"
    struct Connectivity {
      static let sharedInstance = NetworkReachabilityManager()!
      static var isConnectedToInternet:Bool {
          return self.sharedInstance.isReachable
        }
    }
    override func viewDidLoad() {
           super.viewDidLoad()
           // Do any additional setup after loading the view, typically from a nib.
          // recaptcha?.configureWebView { [weak self] webview in
          //     webview.frame = self?.view.bounds ?? CGRect.zero
          // }

        self.showAlertController()
           //self.view.backgroundColor = UIColor.white
    
       }
    /*let recaptcha = try? ReCaptcha(
        apiKey: "6LdMJDEaAAAAAJ7K4b101Gh2xH75vLI3NaRdbk-k",
        //apiKey: "6LdMJDEaAAAAAA7_-LEndYtSnvgdhZaZzhW8oImh",
        baseURL: URL(string: "https://eservices.bip.sa/")!
    )*/
    
    @objc func checkBoxAction(_ sender: UIButton)
    {
        if sender.isSelected
        {
            sender.isSelected = false
            let btnImage    = UIImage(named: "unCheckBoxImage")!
            sender.setBackgroundImage(btnImage, for: UIControl.State())
            ItisRobort = "YES"
        }else {
            sender.isSelected = true
            let btnImage    = UIImage(named: "checkBoxImage")!
            sender.setBackgroundImage(btnImage, for: UIControl.State())
            ItisRobort = "NO"
        }
    }
    
    @IBOutlet var emailTField: UITextField!
    @IBOutlet var passTField: UITextField!
    
    @IBAction func bMasuk(_ sender: Any) {
        if Connectivity.isConnectedToInternet {
            print("Connected")
            //_ = SweetAlert().showAlert("GOOD", subTitle: "THERE IS NETWORK CONNECTION", style: AlertStyle.success)

         } else {
            print("No Internet")
            _ = SweetAlert().showAlert("FAILD!", subTitle: "THERE IS NO NETWORK CONNECTION!", style: AlertStyle.warning)
             return
        }
        
        guard let email = emailTField.text, !(emailTField.text?.isEmpty)! else { return
                _ = SweetAlert().showAlert("Faild!", subTitle: "Username empty!", style: AlertStyle.warning)
        }
        guard let password = passTField.text, !(passTField.text?.isEmpty)! else { return
                _ = SweetAlert().showAlert("Faild!", subTitle: "Password empty!", style: AlertStyle.warning)
        }
       
        if(ItisRobort == "NO"){
         print(ItisRobort)
        _ = SecondViewController()
        let urlLis = "https://swapi.dev/api/people/"
        
        let parameter: Parameters = [
            "email": email,
            "password": password
        ]

            AF.request(urlLis, method: .get, parameters: parameter, encoding: URLEncoding.default, headers: nil)
                .validate(statusCode: 200..<450)
                .responseJSON { response in
                    
                    switch response.result {
                    case .success(let data):
                        print("isi: \(data)")
                        self.donesegue()
                        
                    case .failure(let error):
        _ = SweetAlert().showAlert("Faild!", subTitle: "Faild to get data From Server!", style: AlertStyle.warning)
                        print("need text")
                        print("Request failed with error: \(error)")
                 }
            }
      }else if(ItisRobort=="YES"){
            print(ItisRobort)
            _ = SweetAlert().showAlert("Faild!", subTitle: "Sorry You Are Robort!", style: AlertStyle.warning)
        }
    }
    
    @IBAction func asktovisit(_ sender: Any) {
        if Connectivity.isConnectedToInternet {
            print("Connected")
            //_ = SweetAlert().showAlert("GOOD", subTitle: "THERE IS NETWORK CONNECTION", style: AlertStyle.success)

         } else {
            print("No Internet")
            _ = SweetAlert().showAlert("FAILD!", subTitle: "THERE IS NO NETWORK CONNECTION!", style: AlertStyle.warning)
             return
        }
        if(ItisRobort == "NO"){
            
            //print(serviceName["serv"] as! String)
            print(serviceName as Int)
            
            if(serviceName == 0){
               performSegue(withIdentifier: Segueserv1ViewController, sender: self)
            }else if(serviceName == 1){
               performSegue(withIdentifier: Segueserv2ViewController, sender: self)
            }else if(serviceName == 2){
               performSegue(withIdentifier: Segueserv3ViewController, sender: self)
            }
       }else if(ItisRobort=="YES"){
            _ = SweetAlert().showAlert("Faild!", subTitle: "Sorry You Are Robort!", style: AlertStyle.warning)
        }
        
    }
    
    func donesegue(){
        
     _ = SweetAlert().showAlert("Good job!", subTitle: "You clicked the button!", style: AlertStyle.success)

        performSegue(withIdentifier: self.Segueserv1ViewController, sender: self)
    }
    
    func showAlertController()
        {
            //simple alert dialog
            ItisRobort = "YES"
            let alertController = UIAlertController(title: "أنا لست آليا!", message:"", preferredStyle: UIAlertController.Style.alert);
            // Add Action
            alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.cancel, handler: nil));
            //show it
            let btnImage    = UIImage(named: "unCheckBoxImage")!
            let imageButton : UIButton = UIButton(frame: CGRect(x: 200, y:alertController.view.frame.origin.y+10 , width: 35, height: 35))
            imageButton.setBackgroundImage(btnImage, for: UIControl.State())
            imageButton.addTarget(self, action: #selector(checkBoxAction(_:)), for: .touchUpInside)
            alertController.view.addSubview(imageButton)
            //self.view.backgroundColor = UIColor.gray
            self.present(alertController, animated: false, completion: { () -> Void in

                })
        }

   /* func validate() {
    //  recaptcha?.validate(on: view) { [weak self] (result: ReCaptchaResult) in
          //  print(try? result.dematerialize())
        //}
    }*/

}

