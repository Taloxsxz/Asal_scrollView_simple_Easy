//
//  MainTabBarViewController.swift
//  EServices App
//
//  Created by Admin on 07/06/1442 AH.
//  Copyright © 1442 Admin. All rights reserved.
//

import Foundation
import UIKit
import Alamofire

public var globalindex: NSNumber = 1
class MainTabBarViewController: UITabBarController, UITabBarControllerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.delegate = self
        /*print("HERE 1")
        guard let VCS = self.navigationController?.viewControllers else {return }
        for controller in VCS {
            if controller.isKind(of: MainTabBarViewController.self) {
                let tabVC = controller as! MainTabBarViewController
                tabVC.selectedIndex = 2
                self.navigationController?.popToRootViewController(animated: true)
            }
        }*/

    }
    
    /*@IBAction func switchButtonTapped(sender: UIButton){
        tabBarController?.selectedIndex = 1
        navigationController?.popToRootViewController(animated: true)
    }*/
    
    /*override func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
       // print(item)
        if item.title != "الخدمات الإلكترونية" {  //tab with navigation controller
            print("That 1")
             globalindex = 0
            
              //performSegue(withIdentifier: SegueBooksViewController, sender: self)
        }else{
            if !(self.navigationController?.topViewController is ViewController) {
                    self.navigationController?.popViewController(animated: true)
                }
            print("That 2")
            globalindex = 1
            
        }
        
    }*/
    
    func tabBarController(_ tabBarController: UITabBarController, didSelect viewController: UIViewController) {
        let index = tabBarController.selectedIndex
        if index == NSNotFound || index > 6 {
            tabBarController.moreNavigationController.popToRootViewController(animated: false)
            return
        }
        let navController = tabBarController.viewControllers?[tabBarController.selectedIndex] as? UINavigationController
        navController?.popToRootViewController(animated: false)
    }
  
}
