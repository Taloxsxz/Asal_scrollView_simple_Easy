//
//  FifthViewController.swift
//  EServices App
//
//  Created by Admin on 21/05/1442 AH.
//  Copyright © 1442 Admin. All rights reserved.
//

import Foundation
import UIKit

class FifthViewController: UIViewController {
    let SegueBooksViewController = "askvisit"
    var scrollView: UIScrollView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        scrollView = UIScrollView(frame: self.view.bounds)
        scrollView.contentSize = CGSize(width: self.view.frame.width, height: self.view.frame.height*1.50)
        scrollView.backgroundColor = UIColor.white
        
        print("3 THREE:")
        
        for view1 in self.view.subviews {
            let tempview = view1
            scrollView.addSubview(tempview)
        }
         
         view.addSubview(scrollView)
    }


}
