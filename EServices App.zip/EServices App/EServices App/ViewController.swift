//
//  ViewController.swift
//  EServices App
//
//  Created by Admin on 14/05/1442 AH.
//  Copyright © 1442 Admin. All rights reserved.
//

import UIKit
import ReCaptcha

class ViewController: UITableViewController {

let CellIdentifier = "Cell"
let SegueBooksViewController = "askvisit"

var allservices = [AnyObject]()
let recaptcha = try? ReCaptcha()
    
// MARK: -
// MARK: View Life Cycle
override func viewDidLoad() {
    super.viewDidLoad()
    
    // Set Title
    title = "الخدمات الإلكترونية"
    
    let filePath = Bundle.main.path(forResource: "Books", ofType: "plist")
    
    if let path = filePath {
        allservices = NSArray(contentsOfFile: path)! as [AnyObject]
    }
    tableView.register(UITableViewCell.classForCoder(), forCellReuseIdentifier: CellIdentifier)
    
    
}

override func prepare(for segue: UIStoryboardSegue, sender: Any?) {

     //_ = SweetAlert().showAlert("", subTitle: " أنا لست آليا!", style: AlertStyle.warning)
    
    if segue.identifier == SegueBooksViewController {
        
        let indexPath = tableView.indexPathForSelectedRow
        let author = allservices[indexPath!.row] as? [String: AnyObject]
        let destinationViewController = segue.destination as! FirstViewController
        print(author as Any)
        
        destinationViewController.serviceName = indexPath?.row
        
    }
         //_ = SweetAlert().showAlert("", subTitle: " أنا لست آليا!", style: AlertStyle.warning)
    
}


// MARK: -
// MARK: Table View Data Source Methods
override func numberOfSections(in tableView: UITableView) -> Int {
    return 1
}

override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return allservices.count
}

override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    // Dequeue Resuable Cell
    tableView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")

    let cell = tableView.dequeueReusableCell(withIdentifier: CellIdentifier, for: indexPath as IndexPath)
    let author = allservices[indexPath.row] as? [String: AnyObject]
    let name = author!["serv"]
        // Configure Cell
        //print(authors)
    cell.textLabel?.text = (name as! String)
    
    
    return cell;
}

// MARK: -
// MARK: Table View Delegate Methods
override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    // Perform Segue
    print("YES")
    performSegue(withIdentifier: SegueBooksViewController, sender: self)
    tableView.deselectRow(at: indexPath as IndexPath, animated: true)
}


}

